#ifndef PROTOCOL_H
#define PROTOCOL_H

// STATUS
#define STATUS_OK                  0
#define ERR_DEVICE_NOT_FOUND       1
#define ERR_INVALID_COMMAND        2
#define ERR_LINK_FAILED            3
#define ERR_DEVICE_TYPE_MISMATCH   4
#define STATUS_MANUAL_OVERRIDE     5
#define ERR_DEVICE_CRASHED         6
#define ERR_INVALID_PARAM          7
#define ERR_CYCLE_DETECTED         8
#define ERR_NOT_FOUND              9
#define ERR_SELF_LINK              10
#define ERR_TIMEOUT                11
#define ERR_RESOURCE_ERROR         12
#define ERR_PERMISSION_ERROR       13

// IPC COMMANDS
#define CMD_INFO            "INFO"
#define CMD_SWITCH          "SWITCH"
#define CMD_SET             "SET"
#define CMD_LINK_CHILD      "LINK"
#define CMD_UNLINK_CHILD    "UNLINK"
#define CMD_SET_PARENT      "SET_PARENT"
#define CMD_DELETE          "DELETE"
#define CMD_MIRROR          "MIRROR"
#define CMD_MIRROR_RESP     "MIRROR_RESP"
#define CMD_CHILD_DIED      "CHILD_DIED"

// SYSTEM CONSTANTS
#define MAX_MSG_LEN 512

// Standard format for FIFO path
#define FIFO_PATH_FMT "/tmp/domotica_%s_%d.fifo"

// Fixed path for the Controller FIFO
#define FIFO_CONTROLLER "/tmp/domotica_controller_0.fifo"

// RESPONSE FORMATTING
#define RESP_FORMAT "%d %s"
#define RESP_FORMAT_NO_PAYLOAD "%d" 

#define FIELD_SEP ';'
#define KV_SEP '='
// e.g.: 0 power=on;time=45

// ID reserved for the controller
#define CONTROLLER_ID 0

#endif
