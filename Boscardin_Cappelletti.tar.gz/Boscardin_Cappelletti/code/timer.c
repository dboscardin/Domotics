#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdbool.h>
#include <time.h>

#include "timer.h"
#include "ipc.h"
#include "device.h"
#include "protocol.h"

// Returns textual name of the device type
static const char *get_device_type_name(DeviceType type) {
    switch (type) {
        case DEVICE_BULB:       return "Bulb";
        case DEVICE_WINDOW:     return "Window";
        case DEVICE_FRIDGE:     return "Fridge";
        case DEVICE_CONTROLLER: return "Controller";
        case DEVICE_HUB:        return "Hub";
        case DEVICE_TIMER:      return "Timer";
        default:                return "Unknown";
    }
}

TimerDevice create_timer_struct(int id){

    TimerDevice timer = {
        .id = id,
        .parent_id = -1,
        .num_children = 0,
        .begin = "",
        .end = ""
    };
    return timer;
}

// Mirroring
// Timer does not store child state, but queries it on demand
static void get_timer_state(TimerDevice *timer, int fd_ascolto, char *out_state, size_t state_len) {
    if (timer->num_children == 0) {
        snprintf(out_state, state_len, "None");
        return;
    }

    snprintf(out_state, state_len, "Unknown");
    int child_id = timer->children[0].id;
    DeviceType child_type = timer->children[0].type;

    int fd_child = ipc_open_for_writing(child_id, child_type);
    if (fd_child != -1) {
        char cmd[MAX_MSG_LEN];
        // Send MIRROR
        snprintf(cmd, sizeof(cmd), "%s %d %d", CMD_MIRROR, timer->id, DEVICE_TIMER);
        ipc_send_message(fd_child, cmd);
        close(fd_child);
    }

    int timeout = 1000; 
    // Wait for reply from child
    while (timeout > 0) {
        char buf[4096];
        if (ipc_read_line(fd_ascolto, buf, sizeof(buf)) > 0) {
            char *ptr = buf;
            while ((ptr = strstr(ptr, CMD_MIRROR_RESP)) != NULL) {
                int resp_id;
                char resp_state[MAX_MSG_LEN];
                
                if (sscanf(ptr, "%*s %d %s", &resp_id, resp_state) == 2) {      
                    if (resp_id == child_id) {
                        snprintf(out_state, state_len, "%s", resp_state);
                        return; 
                    }
                }
                ptr += strlen(CMD_MIRROR_RESP);
            }
        } else {
            usleep(50000);
            timeout--;
        }
    }
}


void timer_run(TimerDevice *timer){

    srand(time(NULL) ^ getpid());

    int fd_ascolto = ipc_open_for_listening(timer->id,DEVICE_TIMER);
    char buffer[MAX_MSG_LEN];

    // Prevents the Timer from spamming power on/off commands
    char last_triggered[6] = "";

    while(1){


        // Timer logic
        time_t rawtime;
        struct tm *timeinfo;
        char current_time[6];
        time(&rawtime);
        timeinfo = localtime(&rawtime);
        // Formats current time as "HH:MM" string
        strftime(current_time,sizeof(current_time), "%H:%M", timeinfo);
        

        if(timer->num_children > 0 && strlen(timer->begin) > 0 && strlen(timer->end) > 0){
            int child_id = timer->children[0].id;
            DeviceType child_type = timer->children[0].type;

            // Check the device type
            const char *labelOn = "power";
            const char *labelOff = "power";
            const char *actionOff = "off"; // Standard power-off action
            
            if (child_type == DEVICE_WINDOW || child_type == DEVICE_FRIDGE) {
                labelOn = "open";
                labelOff = "close";
                actionOff = "on"; // Windows and fridges are closed by sending 'close on'
            }

            // Begin schedule triggered
            if (strcmp(current_time, timer->begin) == 0 && strcmp(last_triggered, timer->begin) != 0) {
                int fd_child = ipc_open_for_writing(child_id, child_type);
                if (fd_child != -1) {
                    char cmd[MAX_MSG_LEN];
                    snprintf(cmd, sizeof(cmd), "%s %s on %d %d", CMD_SWITCH, labelOn, timer->id, DEVICE_TIMER);
                    ipc_send_message(fd_child, cmd); 
                    close(fd_child);

                    // Wait for a response from the child
                    int msg = 0;
                    int timeout = 1000;
                    while (msg < 1 && timeout > 0) {
                        char msg_buf[MAX_MSG_LEN];
                        int n = ipc_read_line(fd_ascolto, msg_buf, sizeof(msg_buf));
                        if (n > 0 && strncmp(msg_buf, "MSG", 3) == 0) msg++;
                        else { usleep(10000); timeout--; }
                    }

                    // Notify the controller
                    char alert[MAX_MSG_LEN];
                    snprintf(alert, sizeof(alert), "\nTimer %d automatically switched its device on at %s", timer->id, current_time);
                    ipc_send_controller(STATUS_OK, alert);

                }
                snprintf(last_triggered, sizeof(last_triggered), "%s", current_time);

            } 
            // End schedule triggered
            else if (strcmp(current_time, timer->end) == 0 && strcmp(last_triggered, timer->end) != 0) {
                int fd_child = ipc_open_for_writing(child_id, child_type);
                if (fd_child != -1) {
                    char cmd[MAX_MSG_LEN];
                    snprintf(cmd, sizeof(cmd), "%s %s %s %d %d", CMD_SWITCH, labelOff, actionOff, timer->id, DEVICE_TIMER);
                    ipc_send_message(fd_child, cmd);
                    close(fd_child);

                    // Wait for a response from the child
                    int msg = 0;
                    int timeout = 1000;
                    while (msg < 1 && timeout > 0) {
                        char msg_buf[MAX_MSG_LEN];
                        int n = ipc_read_line(fd_ascolto, msg_buf, sizeof(msg_buf));
                        if (n > 0 && strncmp(msg_buf, "MSG", 3) == 0) msg++;
                        else { usleep(10000); timeout--; }
                    }

                    // Notify the controller
                    char alert[MAX_MSG_LEN];
                    snprintf(alert, sizeof(alert), "\nTimer %d automatically switched its device OFF at %s", timer->id, current_time);
                    ipc_send_controller(STATUS_OK, alert);
                }
                snprintf(last_triggered, sizeof(last_triggered), "%s", current_time);
            }
        }


        // Handle IPC commands
        int bytes_letti = ipc_read_line(fd_ascolto,buffer,sizeof(buffer));

        if(bytes_letti > 0){

            // LINK
            if(strncmp(buffer, CMD_LINK_CHILD, strlen(CMD_LINK_CHILD)) == 0){
                ipc_simulate_delay();
                int child_id;
                int child_type;
                
                if(sscanf(buffer,"%*s %d %d ", &child_id, &child_type) == 2){
                    if(timer->num_children >= MAX_TIMER_CHILDREN){
                        ipc_send_controller(ERR_LINK_FAILED, "Failed to link: Timer can only have 1 direct child.");
                    } else {
                        timer->children[0].id = child_id;
                        timer->children[0].type = child_type;
                        timer->num_children = 1;
                        char msg[MAX_MSG_LEN];
                        snprintf(msg,sizeof(msg),"Link completed: Device %d is now scheduled by Timer %d.", child_id, timer->id);
                        ipc_send_controller(STATUS_OK,msg);
                    }
                }
            }
            // SET_PARENT
            else if(strncmp(buffer, CMD_SET_PARENT, strlen(CMD_SET_PARENT)) == 0){
                int p_id;
                if (sscanf(buffer, "%*s %d", &p_id) == 1){ 
                    timer->parent_id = p_id;
                }
                continue;
            }
            // UNLINK
            else if(strncmp(buffer, CMD_UNLINK_CHILD, strlen(CMD_UNLINK_CHILD)) == 0){
                ipc_simulate_delay();
                int child_id;
                if (sscanf(buffer, "%*s %d", &child_id) == 1){
                    if (timer->num_children > 0 && timer->children[0].id == child_id) {

                        // Notify child to remove this timer as parent
                        int fd_child = ipc_open_for_writing(child_id,timer->children[0].type);
                        if(fd_child != -1){
                            char cmd_unlink[MAX_MSG_LEN];
                            snprintf(cmd_unlink, sizeof(cmd_unlink), "%s -1", CMD_SET_PARENT);
                            ipc_send_message(fd_child, cmd_unlink);
                            close(fd_child);
                        }

                        // Remove the child
                        timer->num_children = 0;
                        char msg[MAX_MSG_LEN];
                        snprintf(msg,sizeof(msg), "Unlink completed: Device %d removed from Timer.", child_id);
                        ipc_send_controller(STATUS_OK, msg);
                        
                    } else {
                        char msg[MAX_MSG_LEN];
                        snprintf(msg,sizeof(msg), "Notice: Device %d is not linked to this Timer.", child_id);
                        ipc_send_controller(ERR_NOT_FOUND, msg);
                    }
                }
            }
            // SWITCH
            else if(strncmp(buffer, CMD_SWITCH, strlen(CMD_SWITCH)) == 0){
                ipc_simulate_delay();
                char label[32], pos[32];
                int sender_id = -1, sender_type = -1;
                int parsed = sscanf(buffer, "%*s %s %s %d %d", label, pos, &sender_id, &sender_type);

                // Configure Timer schedule
                if (strcmp(label, "begin") == 0 || strcmp(label, "end") == 0) {
                    int h, m;
                    if (sscanf(pos, "%d:%d", &h, &m) == 2 && h >= 0 && h <= 23 && m >= 0 && m <= 59) {

                        // Get current time to check if time has passed
                        time_t rawtime; struct tm *timeinfo; char current_time[6];
                        time(&rawtime); timeinfo = localtime(&rawtime);
                        strftime(current_time, sizeof(current_time), "%H:%M", timeinfo);

                        bool valid = true;
                        char err_msg[MAX_MSG_LEN] = "";

                        // Data validation
                        if (strcmp(pos, current_time) < 0) {
                            valid = false;
                            snprintf(err_msg, sizeof(err_msg), "Error: Time %s is in the past!", pos);
                        } else if (strcmp(label, "begin") == 0 && strlen(timer->end) > 0 && strcmp(pos, timer->end) >= 0) {
                            valid = false;
                            snprintf(err_msg, sizeof(err_msg), "Error: Begin time cannot be >= End time.");
                        } else if (strcmp(label, "end") == 0 && strlen(timer->begin) > 0 && strcmp(timer->begin, pos) >= 0) {
                            valid = false;
                            snprintf(err_msg, sizeof(err_msg), "Error: End time cannot be <= Begin time.");
                        }

                        if(valid){
                            if (strcmp(label, "begin") == 0) {
                                snprintf(timer->begin, sizeof(timer->begin), "%02d:%02d", h, m);
                                if (parsed < 3) ipc_send_controller(STATUS_OK, "Timer begin set.");
                            } else {
                                snprintf(timer->end, sizeof(timer->end), "%02d:%02d", h, m);
                                if (parsed < 3) ipc_send_controller(STATUS_OK, "Timer end set.");
                            }
                        } else {
                            if (parsed < 3) ipc_send_controller(ERR_INVALID_PARAM, err_msg);
                        }
                    } else {
                        if (parsed < 3) ipc_send_controller(ERR_INVALID_PARAM, "Invalid time format! Use HH:MM.");
                    }
                    
                    if (parsed >= 3) {
                        // Unblock parent if any
                        int fd_parent = ipc_open_for_writing(sender_id, (DeviceType)sender_type);
                        if(fd_parent != -1) {
                            char cmd[32];
                            snprintf(cmd, sizeof(cmd), "MSG %d", timer->id);
                            ipc_send_message(fd_parent, cmd);
                            close(fd_parent);
                        }
                    }
                } 
                else {
                    // Forward manual switch commands to child
                    if (timer->num_children > 0) {
                        int child_id = timer->children[0].id;
                        DeviceType child_type = timer->children[0].type;

                        // Check device type
                        const char *out_label = label;
                        const char *out_pos = pos;
                        if (child_type == DEVICE_WINDOW || child_type == DEVICE_FRIDGE) {
                            if (strcmp(pos, "on") == 0) {
                                out_label = "open";
                                out_pos = "on";
                            } else {
                                out_label = "close";
                                out_pos = "on";
                            }
                        }
                        
                        int fd_child = ipc_open_for_writing(child_id, child_type);
                        if (fd_child != -1) {
                            char cmd[MAX_MSG_LEN];
                            snprintf(cmd, sizeof(cmd), "%s %s %s %d %d", CMD_SWITCH, out_label, out_pos, timer->id, DEVICE_TIMER);
                            ipc_send_message(fd_child, cmd);
                            close(fd_child);
                        }
                        
                        int msg = 0;
                        int timeout = 1000;
                        while (msg < 1 && timeout > 0) {
                            char msg_buf[MAX_MSG_LEN];
                            int n = ipc_read_line(fd_ascolto, msg_buf, sizeof(msg_buf));
                            if (n > 0 && strncmp(msg_buf, "MSG", 3) == 0){
                                msg++;
                            } else { 
                                usleep(10000); timeout--; 
                            }
                        }
                    }

                    if (parsed >= 3) {
                        int fd_parent = ipc_open_for_writing(sender_id, (DeviceType)sender_type);
                        if(fd_parent != -1) {
                            char ack[32];
                            snprintf(ack, sizeof(ack), "MSG %d", timer->id);
                            ipc_send_message(fd_parent, ack);
                            close(fd_parent);
                        }
                    } else {
                        ipc_send_controller(STATUS_OK, "Timer forwarded switch command.");
                    }
                }

            }
            // DELETE
            else if(strncmp(buffer, CMD_DELETE, strlen(CMD_DELETE)) == 0){

                int sender_id = -1;
                int sender_type = -1;

                if (timer->num_children > 0) {
                    int child_id = timer->children[0].id;
                    DeviceType child_type = timer->children[0].type;
                    
                    int fd_child = ipc_open_for_writing(child_id, child_type);
                    if (fd_child != -1) {
                        char cmd[MAX_MSG_LEN];
                        snprintf(cmd, sizeof(cmd), "%s %d %d", CMD_DELETE, timer->id, DEVICE_TIMER);
                        ipc_send_message(fd_child, cmd);
                        close(fd_child);
                    }

                    // Wait for children to be deleted
                    int deleted = 0;
                    int timeout = 1000;
                    while (deleted < 1 && timeout > 0) {
                        char deleted_buf[MAX_MSG_LEN];
                        int n = ipc_read_line(fd_ascolto, deleted_buf, sizeof(deleted_buf));
                        if (n > 0 && strncmp(deleted_buf, "MSG", 3) == 0) {
                            deleted++;
                        } else {
                            usleep(10000);
                            timeout--;
                        }
                    }
                }

                // Respond to whoever requested deletion
                if (sscanf(buffer, "%*s %d %d", &sender_id, &sender_type) == 2) {
                    int fd_parent = ipc_open_for_writing(sender_id, (DeviceType)sender_type);
                    if (fd_parent != -1) {
                        char msg[32];
                        snprintf(msg, sizeof(msg), "MSG %d", timer->id);
                        ipc_send_message(fd_parent, msg);
                        close(fd_parent);
                    }
                } else {
                    char msg[MAX_MSG_LEN];
                    int offset = 0;
                    offset += snprintf(msg + offset, sizeof(msg) - offset, "Timer %d and all its children deleted.\n", timer->id);
                    if (timer->num_children > 0) {
                        offset += snprintf(msg + offset, sizeof(msg) - offset, "Device %s %d deleted.\n", get_device_type_name(timer->children[0].type), timer->children[0].id);
                    }
                    ipc_send_controller(STATUS_OK, msg);
                }
                
                close(fd_ascolto);
                exit(0);

            }
            // INFO
            else if(strncmp(buffer, CMD_INFO, strlen(CMD_INFO)) == 0){
                char message[MAX_MSG_LEN];
                int offset = 0;

                offset += snprintf(message + offset, sizeof(message) - offset,
                "\n------- Timer Details ------\nID: %d\n", timer->id);

                if (timer->parent_id == -1) offset += snprintf(message + offset, sizeof(message) - offset, "Linked to Hub: no\n");
                else offset += snprintf(message + offset, sizeof(message) - offset, "Linked to Hub ID: %d\n", timer->parent_id);

                offset += snprintf(message + offset, sizeof(message) - offset, "Schedule: %s -> %s\n", 
                strlen(timer->begin) > 0 ? timer->begin : "Not set",
                strlen(timer->end) > 0 ? timer->end : "Not set");

                if (timer->num_children == 0) {
                    offset += snprintf(message + offset, sizeof(message) - offset, "Linked Device: none\n");
                } else {
                    // Real state
                    char child_state[64];
                    get_timer_state(timer, fd_ascolto, child_state, sizeof(child_state));

                    offset += snprintf(message + offset, sizeof(message) - offset, "Linked Device ID: %d | Type: %s | State: %s\n", 
                        timer->children[0].id, get_device_type_name(timer->children[0].type), child_state);
                    
                    if (strstr(child_state, "Manual_Override")) {
                        offset += snprintf(message + offset, sizeof(message) - offset, "Manual_Override\n");
                    }
                }
                
                offset += snprintf(message + offset, sizeof(message) - offset, "----------------------------\n");
                ipc_send_controller(STATUS_OK, message);

            }
            // MIRROR
            else if (strncmp(buffer, CMD_MIRROR, strlen(CMD_MIRROR)) == 0) {
                int p_sender_id;
                int p_sender_type;
                if (sscanf(buffer, "%*s %d %d", &p_sender_id, &p_sender_type) == 2) {
                    char child_state[64];
                    get_timer_state(timer, fd_ascolto, child_state, sizeof(child_state));
                    
                    int fd_parent = ipc_open_for_writing(p_sender_id, p_sender_type);
                    if (fd_parent != -1) {
                        char resp[MAX_MSG_LEN];
                        snprintf(resp, sizeof(resp), "%s %d %s ", CMD_MIRROR_RESP, timer->id, child_state);
                        ipc_send_message(fd_parent, resp);
                        close(fd_parent);
                    }
                }
            }
            // CHILD_DIED 
            else if (strncmp(buffer, CMD_CHILD_DIED, strlen(CMD_CHILD_DIED)) == 0) {
                int dead_id;
                if (sscanf(buffer, "%*s %d", &dead_id) == 1) {
                    if (timer->num_children > 0 && timer->children[0].id == dead_id) {
                        timer->num_children = 0;
                    }
                }
            } else {
                ipc_send_controller(ERR_INVALID_COMMAND,"Timer unknown command.");
            }
        } else{
            // If the FIFO is empty, sleep for 50ms to avoid consuming 100% CPU
            usleep(50000);
        }
    }

    close(fd_ascolto);
    exit(0);
}



void create_timer(int id){
    TimerDevice timer = create_timer_struct(id);
    timer_run(&timer);
}